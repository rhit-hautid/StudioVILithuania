module StudioVILithuania {
	requires java.desktop;
}